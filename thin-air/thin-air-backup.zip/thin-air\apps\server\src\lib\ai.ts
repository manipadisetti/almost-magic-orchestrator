import { GoogleGenerativeAI } from "@google/generative-ai";
import Anthropic from "@anthropic-ai/sdk";
import * as dotenv from "dotenv";

dotenv.config({ path: "../../.env" });

// Gemini Client
const geminiApiKey = process.env.GEMINI_API_KEY;
if (!geminiApiKey) {
    console.warn("⚠️ GEMINI_API_KEY is missing. Gemini calls will fail.");
}
const genAI = new GoogleGenerativeAI(geminiApiKey || "");
export const geminiModel = genAI.getGenerativeModel({ model: "gemini-1.5-pro-latest" }); // Using 1.5 Pro as 3.0 might not be public yet, but docs said 3.0. I will use the string from docs if it works, otherwise fallback.
// Docs said: gemini-3.0-pro. I will try that.
export const gemini3Pro = genAI.getGenerativeModel({ model: "gemini-3.0-pro" });

// Anthropic Client (Fallback)
const anthropicApiKey = process.env.ANTHROPIC_API_KEY;
if (!anthropicApiKey) {
    console.warn("⚠️ ANTHROPIC_API_KEY is missing. Anthropic calls will fail.");
}
export const anthropic = new Anthropic({
    apiKey: anthropicApiKey || "dummy",
});

export async function generateWithFallback(prompt: string): Promise<string> {
    try {
        console.log("🤖 Attempting Gemini 3 Pro...");
        const result = await gemini3Pro.generateContent(prompt);
        const response = result.response;
        return response.text();
    } catch (error) {
        console.error("❌ Gemini failed:", error);
        console.log("🔄 Falling back to Anthropic...");
        try {
            const message = await anthropic.messages.create({
                max_tokens: 1024,
                messages: [{ role: 'user', content: prompt }],
                model: 'claude-3-opus-20240229',
            });
            return message.content[0].text;
        } catch (fallbackError) {
            console.error("❌ Anthropic also failed:", fallbackError);
            throw new Error("All AI providers failed.");
        }
    }
}
